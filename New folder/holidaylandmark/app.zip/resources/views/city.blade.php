@if(sizeof($city) >0)


<style>
.td {
border: 5px solid black !important;
}   
.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: blue;
  text-decoration:none;
}

/* selected link */
a:active {
   color: white;
}
.col-9
{


}
@import url('https://fonts.googleapis.com/css2?family=Peddana&family=Roboto:wght@300&display=swap');
p{
    font-family: 'Peddana', serif;
    word-spacing: 4px; 
}

</style>
<tr  >
<td>
<div  class="row">
  
     
     @foreach ($city as $cities) 
<div class="col-md-4"> 


            <img class="w-100 py-3" style="border-radius: 5px; transition: .3s;cursor: pointer;" src="public/category/{{$cities->Image}}">
            <h1 class="centered"><a href="{{ route('showcity',$cities->slug) }}" target="_blank"><b style="font-size: 24px;">
            {{$cities->city_name}}            </b></a>
           </h1> 
           
             


</div>
@endforeach




     </div>
    



               <br>
               </td>
            </tr> 
            
            
            
        @else
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th style="font-size: 22px; color:red;">Data not found</th>
            <th></th>
            <th></th>
        </tr>
        @endif
