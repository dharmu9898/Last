<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	h2, h4{
		color: #8E9093;
	}
	body{
		padding: 0px;
		margin:0px;
	}



</style>
<body>
	<div style=" margin-left:20%; margin-right: 20%; margin-top: 4%;">
		<div style="border: 1px solid black;">
<div style="background: #E8FDE8;
height: 100%;
font-size: 3em;
font-weight: bold;
padding: 1%;
text-align:  center;">
	
</div>

<p style="margin-left:10%;">Message -  <b>{{ $OperatorMailsend['message'] }}</b></p>
<p style="margin-left:10%;">Email ID  & Password both are same- <b> {{ $OperatorMailsend['email'] }} </b></p>
<h2 style="margin-left:10%;">The intrduction to the notification.</h2>
<hr>

<a href="http://localhost/app/password/reset" style="color:black; text-decoration:none;">

    Create Password </a> </button>
<h4 style="margin-left:10%;">Thank you for completing.
    </h4>
    <h5 style="margin-left:10%;">
        Regards, <br>
        DevOpsSchool.com/cv team <br>
        Email - Contact@DevOpsSchool.com <br>
    </h5>
<div style="background: #E8FDE8;
    height: 100%;
    font-weight: bold;

    text-align:  center;">© Copyright 2020 DevOpsSchool.com/cv Team </span>

</div>
</div>
</div>
</body>
</html>








