@extends('layouts.backend.app')


@section('content')

<div class="row mt--6 ">
 <div class="col-md-11">
  <br />
  <h1 align="center">Add a New Trip </h1>
  <br />
  <div id="mydiv">
  @if(count($errors) > 0)
  <div class="alert alert-danger">
   <ul>
   @foreach($errors->all() as $error)
    <li>{{$error}}</li>
   @endforeach
   </ul>
  </div>
  @endif
  @if(\Session::has('success'))
  <div class="alert alert-success">
   <p>{{ \Session::get('success') }}</p>
  </div>
  @endif
</div>

  <form method="post" action="{{route('touroperator.store')}}" enctype="multipart/form-data">
   {{csrf_field()}}   
      
 
    
   <div class="form-group">
   <select name="country" class="form-control countries" id="countryId">
    <option value="">Select Country</option>
</select>
   </div>   
   <div class="form-group">
   <select name="state" class="form-control states" id="stateId">
    <option value="">Select State</option>
</select>
   </div>
   <div class="form-group">
   <select name="city" class="form-control cities" id="cityId">
    <option value="">Select City</option>
</select>
   </div>
          
            <div class="form-group">
                <strong>Email Id:</strong>
                <input type="text" name="emailid" class="form-control" placeholder="emailid">
            </div>
      
          <div class="form-group">
                <strong>Phone no:</strong>
                <input type="text" name="Phoneno" class="form-control" placeholder="Phoneno">
            </div>
      
   <div class="form-group">
                <strong>Trip Title:</strong>
                <input type="text" name="triptitle" class="form-control" placeholder="triptitle">
            </div>
      <div class="form-group">
                <strong>No of days:</strong>
                <input type="text" name="Noofdays" class="form-control" placeholder="Noofdays">
            </div>
      
<div class="form-group">
                <strong>Location:</strong>
                <input type="text" name="location" class="form-control" placeholder="location">
            </div>

<div class="form-group">
                <strong>Location:</strong>
                <input type="text" name="location" class="form-control" placeholder="location">
            </div>
 <button  style="float:centre" type="button" class="btn btn-info" data-toggle="collapse" id="#collapse example">
      Iternary Form</button>
      


<br>
   <div style="float:right" class="form-group">
    <input type="submit" class="btn btn-primary"  />
   </div>
  </form>



 </div>
</div>


@endsection
 <script src="{{asset('js/jquery.js')}}"></script>
       <script>
           $(document).ready(function(){
            $('select[name="country"]').on('change',function(){
                var country_id= $(this).val();
                if (country_id) {
                 $.ajax({
                    url: "{{url('/getStates/')}}/"+country_id,
                  type: "GET",
                  dataType: "json",
                  success: function(data){
                    console.log(data);
                    $('select[name="state"]').empty();
                    $.each(data,function(key,value){
                        $('select[name="state"]').append('<option value="'+key+'">'+value+'</option>');
                    });
                  }
                 });
                }else {
                     $('select[name="state"]').empty();
               }
           });
             $('select[name="state"]').on('change',function(){
                var state_id= $(this).val();
                if (state_id) {
                 $.ajax({
                    url: "{{url('/getCities/')}}/"+state_id,
                  type: "GET",
                  dataType: "json",
                  success: function(data){
                    console.log(data);
                    $('select[name="city"]').empty();
                    $.each(data,function(key,value){
                        $('select[name="city"]').append('<option value="'+key+'">'+value+'</option>');
                    });
                  }
                 });
                }else {
                     $('select[name="city"]').empty();
               }
           });
           });
       </script>

