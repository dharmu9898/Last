@if(sizeof($gallery) > 0)

    @foreach ($gallery as $gall)
        <tr>
        <td     >
            <?php
       foreach (json_decode($gall->Image)as $picture) { ?>
                 <img class="center" src="{{ asset('public/image/'. $picture) }}"
                  style="height:35px;  width:60px;border-radius: 5px; transition: .3s;cursor: pointer;"/>
                
                  @break <?php 
            
           
            
            } ?> </td>
             
            <td >{{ $gall->TripTitle }}</td>
            <td>{{ $gall->country_name }}</td>
            <td>{{ $gall->state_name }}</td>
            <td>{{ $gall->city_name }}</td>
            
            <td >{{ $gall->datetime }}</td>
    
    </td>
    
            
           
<td style="text-align:center;"> 
    


       <form action="{{route('touroperator.destroygallery', $gall->id)}}" method="get">
   
                    
                    <a style="color:white;" class="btn btn-primary" href="{{ route('touroperator.editgallery',$gall->id) }}">Edit</a>
                    <a style="color:white;" class="btn btn-success" href="{{ route('touroperator.showgallery',$gall->id) }}">Show</a>
    
                    @csrf
                    @method('DELETE')
      
                    <button  style="color:white;" type="submit" class="btn btn-danger">Delete</button>
                </form>
            
    </td>
   

        </tr>
        @endforeach
        

   @else
           <tr>
             <td colspan="8">
                  <p style="text-align:center;">No Data found</p>
            </td>
            </tr>
      @endif 

     
