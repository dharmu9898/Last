@extends('layouts.adminsidebar')

@section('content')
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{
  overflow-x:hidden;
  font-family: "Times New Roman", Times, serif;
}
.tab1{
margin-left:-4%;
}

table{
    font-family: "Times New Roman", Times, serif;
}
th{
    font-family: "Times New Roman", Times, serif;

}
td{
    font-family: "Times New Roman", Times, serif;

}

tr{
    font-family: "Times New Roman", Times, serif;

}
.myrow
{
    margin-left:275px;  
}

th {
  font-size: 17px;
}
td {
  font-size: 17px;
}
.action
{
  padding-left:90px;
}



}
/* @media only screen and (max-width: 1200px) {
  .tab1{
margin-left:0%;
}
} */
</style>

<div class="row">
                    <div class="col-12">
                        <div class="card">
                        <div class="col-12">
                        <div class="text-right upgrade-btn">
                      
                            <a href='{{url("admin/operator/create")}}'  style="font-size:20px;padding:4px;" class="btn btn-success text-white" target="_blank">Add Tour Operator</a>
                            <a href="{{route('admin.changepwd', Auth::user()->id)}}"class="btn btn-success text-white" style="font-size:20px;padding:4px;"> &nbsp;
                               Change Password </a>
                       
                        </div>
                    </div>
                            <div class="card-body">

                          
                            <div class="form-group">
                <div class="row">
                <div class="col-md-4">
                  <select class="form-control countries" name="manual_filter_table" id="manual_filter_table">
                      <option value="">Select Your Country</option>
                  </select>
                </div>
              <div class="col-md-4">
                <select class="form-control states" name="manual_filter_table1" id="manual_filter_table1">
                      <option value="">Select Your State</option>
                  </select>
              </div>
              <div class="col-md-4">
                <select class="form-control cities" name="manual_filter_table2" id="manual_filter_table2">
                            <option value="">Select Your City</option>
                  </select>
              </div>
              </div>
          </div>
                      
                     
      <div class="form-group">
      <input type="text" class="form-control" name="manual_filter_tablesm" id="manual_filter_tablesm" placeholder="Search Keyword.." style="font-size:18px;">
  </div>


                                                        <div class="table-responsive">

                                                      
                                <table id="myTable"  class="table table-bordered">
   <thead     style="color:black"><tr>
    
   


                                                  
                                                <th  class="mob">Name</th>
                                                <th >Country</th>
                                                <th >State</th>
                                                <th >City</th>
                                                <th >Email</th>
                                               
                                                <th >Action</th>
    </tr>
   </thead>
   <tbody style="color:black" id="myTable">
   @include('admin.operator.paginated_data')

   </tbody>
  </table> 
                                </div>
                                  </div>
                            </div>
                            </div>

                            <div class="col-lg-12 margin-tb">
        <div class="pull-right">
           
        </div>
                        <div class="pull-right">
                             @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                
            </div>
        </div>
        <script>
    function welcome_fetch_data(page, manual_filter, manual_filter_tablesm){

    
      
                $.ajax({
                url:"{{ url('admin/operator/index/welcomes_manualfilter')}}?page="+page+"&manual_filter_table="+manual_filter+"&manual_filter_tablesm="+manual_filter_tablesm,
                success:function(data){
                 
                    console.log(data);
                    $('#myTable tbody').html('');
                    $('#myTable tbody').html(data);
                }
                });
            }
            $(document).ready(function() {
              $("#manual_filter_table").change(function() {
                $('#manual_filter_tablesm').val('');
                var manual_filter_tablesm = $('#manual_filter_tablesm').val();
                manual_filter = $("#manual_filter_table").val();
                 var page = $('#hidden_page').val();
                 $('#manual_filter_table1 option').prop('selected', function() {
                    return this.defaultSelected;
                });
                 $('#manual_filter_table2 option').prop('selected', function() {
                    return this.defaultSelected;
                });
                welcome_fetch_data(page, manual_filter, manual_filter_tablesm);
              })
            });
        $(document).ready(function() {
              $("#manual_filter_table1").change(function() {
                $('#manual_filter_tablesm').val('');
                var manual_filter_tablesm = $('#manual_filter_tablesm').val();
                manual_filter = $("#manual_filter_table1").val();
                 var page = $('#hidden_page').val();
                 $('#manual_filter_table option').prop('selected', function() {
                    return this.defaultSelected;
                });
                 $('#manual_filter_table2 option').prop('selected', function() {
                    return this.defaultSelected;
                });
                welcome_fetch_data(page, manual_filter, manual_filter_tablesm);
              })
            });
        $(document).ready(function() {
              $("#manual_filter_table2").change(function() {
                $('#manual_filter_tablesm').val('');
                var manual_filter_tablesm = $('#manual_filter_tablesm').val();
                manual_filter = $("#manual_filter_table2").val();
                 var page = $('#hidden_page').val();
                 $('#manual_filter_table option').prop('selected', function() {
                    return this.defaultSelected;
                });
                 $('#manual_filter_table1 option').prop('selected', function() {
                    return this.defaultSelected;
                });
                welcome_fetch_data(page, manual_filter, manual_filter_tablesm);
              })
            });
            $(document).on('keyup', '#manual_filter_tablesm', function(){
              
            var manual_filter_tablesm = $('#manual_filter_tablesm').val();
            manual_filter = $("#manual_filter_table").val();
            var page = $('#hidden_page').val();
            $('#manual_filter_table option').prop('selected', function() {
                    return this.defaultSelected;
                });
            $('#manual_filter_table1 option').prop('selected', function() {
                    return this.defaultSelected;
                });
            $('#manual_filter_table2 option').prop('selected', function() {
                    return this.defaultSelected;
                });
                welcome_fetch_data(page, manual_filter, manual_filter_tablesm);
           });
          $(document).on('click', '.pagination a', function(event){
            event.preventDefault();
             var manual_filter_tablesm = $('#manual_filter_tablesm').val();
            var page = $(this).attr('href').split('page=')[1];
            manual_filter = $("#manual_filter_table").val();
            welcome_fetch_data(page, manual_filter, manual_filter_tablesm);
          });
</script>
   
@endsection
@push('js')


<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script type="text/javascript" src="{{asset('js/jquery.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/bootstrap.min.js')}}"></script>  
    <script type="text/javascript" src="{{asset('js/jquery.prettyPhoto.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/jquery.parallax.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/smoothscroll.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/jquery.nav.js')}}"></script>   
    
    <script type="text/javascript" src="{{asset('js/main.js')}}"></script> 
@endpush