@extends('layouts.apps')

@section('content')
<div style="max-width: 1450px;" class="container">
    <!-- Header -->
    
    <!-- Page content -->

   

  <div class="row justify-content-sm-center">
  <div class="col-md-12">
            <a href="/" title="Home" rel="home">
                <img src="{{ asset('assets/images/logo/holiday-landmark2.png') }}"> 
            </a>
            <hr>
        </div>
        <div  class="col-md-6">
        <h1 style="text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue; color:white;margin-top:15%">
                Welcome to Holiday Landmark</h1>
        </div>
    <div style="float:right;" class="col-md-4">
      <div class="card border-info">
        <div class="card-header">Sign in to continue</div>
        <div class="card-body">
          <div class="row">
            
            <div class="col-md-12">
            <form method="POST" action="{{ route('login') }}">
         @csrf
         <div style="margin-top:20px;" class="form-group row">
                           
                            <div class="col-md-12">
                                <input id="email" style="height:30px;" type="email" class="form-control @error('email') is-invalid @enderror" placeholder="Email" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            
                            <div class="col-md-12">
                                <input id="password" style="height:30px;" type="password" class="form-control @error('password') is-invalid @enderror"  placeholder="Password" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-12 ">
                                <button type="submit" style="width: 400px;" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6 ">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>
                       
                        <div class="form-group row offset-md-2">
                            <div class="col-md-12 ">
                            <a   style="width: 400px;background-color:#e94235;" href="{{ url('auth/google')}}" class="btn btn-neutral btn-icon">
                  <span class="btn-inner--icon"><img src="{{asset('img/icons/google.svg')}}"></span>
                  <span  style="color: white;" class="btn-inner--text">Login or Sign-up with Google</span>
                </a>
                                

                              
                            </div>
                        </div>
                        <div class="form-group row offset-md-2">
                            <div class="col-md-12 ">
                                   <a  style="width: 400px;background-color:#4867aa;" href="{{ url('auth/facebook')}}" class="btn btn-neutral btn-icon">
                  <span class="btn-inner--icon"><img src="{{asset('img/icons/facebook.svg')}}"></span>
                  <span style="color: white;" class="btn-inner--text"> Login or Sign-up with Facebook</span>
                </a>
                                

                              
                            </div>
                        </div>
                        
                
              </form>
            </div>
          </div>
        </div>
      </div>
      <a href="#" class="float-right">Create an account </a>
    </div>
    <div class="col-md-12">
    </div>
  </div>



   

  
@endsection


