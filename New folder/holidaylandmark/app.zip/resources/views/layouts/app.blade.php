<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'DevopsSchool') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
<!-- ==============admin side bar close============ -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  
    <!-- Scripts -->
   
</head>

<body>


    <nav class="navbar navbar-expand-sm bg-white navbar-light text-gray-dark-500 sticky-top"
    style="height:42px; !important;"
    id="nav1">
        <div class="container" id="navs1">
           <a href="index.html" class="pt-2 mt-2 navbar-brand"> <img src="{{asset('img/holiday.png')}}" width="200" height="50" alt=""></a>

           <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
           <span class="navbar-toggler-icon"></span>
            </button>
           <div class="collapse navbar-collapse mt-2" id="navbarCollapse">
              <ul class="navbar-nav ml-auto">
                 <li class="nav-item active">
                    <a href="#" class="nav-link">Home</a>
                 </li>
                 
                 <li class="nav-item">
                    <a href="" class="nav-link">Blog</a>
                 </li>
                 <li class="nav-item">
                    <a href="" class="nav-link">HolidayLandmarker</a>
                 </li>
                 <li class="nav-item">
                    <a href="" class="nav-link">Top Destination</a>
                 </li>
                 <li class="nav-item">
                    <a href="" class="nav-link">You Tube</a>
                 </li>
                 <li class="nav-item">
                    <a href="" class="nav-link">Contact</a>
                 </li>
                 

<!----login open------->




<li class="nav-item">
<span><a href="{{ route('login') }}"><i class="fa fa-sign-in"></i> Login </a></span>
</li>





<!-----login close------->
              </ul>
           </div>
        </div>
         <!--Onscroll Navbar-->
        <div class="container" id="navs2" style="display:none;">
           <a href="index.html" class="pt-4 navbar-brand"> <img src="https://www.devopsschool.com/assets/images/logo/logo.png" width="200" height="50" alt=""></a>
           <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">

           <span class="navbar-toggler-icon"></span>

           </button>
           <div class="collapse navbar-collapse" id="navbarCollapse">
              <ul class="navbar-nav ml-auto">
                 <li class="nav-item active">
                  
                 </li>
                 <li class="nav-item dropdown">
                   
                 </li>
                 <li class="nav-item">
                  
                 </li>
                 <li class="nav-item">
                   
                 </li>
                 <li class="nav-item">
                   
                 </li>
                 <li class="nav-item">
                    
                 </li>
                 <li class="nav-item">
                  
                 </li>
                 <li class="nav-item">
                    
                 </li>
                 <li class="nav-item">
                   
                 </li>
                 <li class="nav-item">
                   
                 </li>
                 <li class="nav-item">
                   
                 </li>
              </ul>
           </div>
        </div>
     </nav>
 </div>
</div>
</div>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{-- {{ config('app.name', 'DevopsSchool11111') }} --}}
                </a>
                <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button> -->

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                   
                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>


<!--Footer -->

<div class="fixed-bottom text-center d-none d-lg-block bg-cyan-900 text-white p-1"><h5><i class="fa fa-phone"></i> &nbsp;
      Call us on +91 700 483 5930&nbsp;  |&nbsp; +91 700 483 5706 &emsp;
      <i class="fa fa-envelope-o"> </i> &nbsp;
     Contact@DevopsSchool.com
      </h5></div>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-108125931-2"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-108125931-2');
</script>

<script type='application/ld+json'>
{
"@context": "http://www.schema.org",
"@type": "Course",
"name": "DevOpsSchool.com | Online and Classroom Training | Web Tutorials | Video Tutorials",
"description": "DevOpsSchool is best online and classroom training provider with the most comprehensive learning system. We help individuals and corporate professionals learn trending technologies for career growth.",
"provider": {
"@type": "Organization",
"name": "DevOpSchool",
"sameAs": "https://www.devopsschool.com"
}
}
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5a5b2a81d7591465c706baa1/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>

<!---country----17-04--2020---->
<script src="{{asset('js/location.js')}}"> </script>
<!----country---17----04--2020------>

<!-- ======== slider on the welcome page ======== -->


<!-- ========close slider on the welcome page ======== -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>


  {{-- manual search open --}}
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

  {{-- manual search close --}}
  <script src="{{asset('js/popper.min.js')}}"></script>  
  
  <script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/togglesnew.js')}}"> </script>
  <script src="{{asset('theme/jquery/dist/jquery.min.js')}}"></script>
  <script src="{{asset('theme/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('theme/js-cookie/js.cookie.js')}}"></script>
  <script src="{{asset('theme/jquery.scrollbar/jquery.scrollbar.min.js')}}"></script>
  <script src="{{asset('theme/jquery-scroll-lock/dist/jquery-scrollLock.min.js')}}"></script>
  <!-- Argon JS -->
  <script src="{{asset('js/argon.js?v=1.1.0')}}"></script>

  <script src="{{asset('js/location.js')}}"> </script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>
