@if(sizeof($gallery) >0)


<style>
.td {
border: 5px solid black !important;
}   
.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.centered1 {
  position: absolute;
  top: 65%;
  left: 50%;
  transform: translate(-50%, -50%);
  color:white;
  font-size:18;
}
.centered2 {
  position: absolute;
  top: 85%;
  left: 50%;
  transform: translate(-50%, -50%);
  color:white;
  font-size:16;
}
.centered3 {
  position: absolute;
  top: 85%;
  left: 50%;
  transform: translate(-50%, -50%);
  color:white;
  font-size:14;
}
.bottom-left3 {
  position: absolute;
  bottom: 0px;
  left: 16px;
  color:white
}
a:link {
  color: white;
}

/* visited link */
a:visited {
  color: white;
}

/* mouse over link */
a:hover {
  color: blue;
  text-decoration:none;
}

/* selected link */
a:active {
    color: white;
}
.col-9
{


}
@import url('https://fonts.googleapis.com/css2?family=Peddana&family=Roboto:wght@300&display=swap');
p{
    font-family: 'Peddana', serif;
    word-spacing: 4px; 
}

</style>
<tr  >
<td style="border-radius:2px;">
<div style="margin-right: 8px;" class="row">
    
@foreach ($gallery as $gall)  
<div class="col-md-4">            

<?php
foreach (json_decode($gall->Image)as $picture) { ?>

     <img class="w-100 py-3" src="{{ asset('public/image/'. $picture) }}"
     style="border-radius: 5px; transition: .3s;cursor: pointer;"/>
    
        @break <?php 



} ?> 
 <h1 class="centered"><a href="{{ route('showcategory',$gall->Category) }}" target="_blank">
   <b style="font-size:24px;">{{$gall->Category}}
    </b></a> </h1>

      
    <h3  class="centered1"><a href="{{ route('showcountry',$gall->slug2) }}" target="_blank"><b >{{$gall->country_name}}</b></a>
           </h3>
           <h5 style="font-size:16;" class="centered2"><a href="{{ route('showstate',$gall->slug1) }}" target="_blank"><b>{{$gall->state_name}}</a>/<span><a href="{{ route('showcity',$gall->slug) }}" target="_blank">{{$gall->city_name}}</a></span></b>
           </h5>
             
</div>

@endforeach
<div class="col-md-8">            


 
</div>




     </div>
               <br>
               </td>
            </tr> 
            
         
            
        @else
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th style="font-size: 22px; color:red;">Data not found</th>
            <th></th>
            <th></th>
        </tr>
        @endif
