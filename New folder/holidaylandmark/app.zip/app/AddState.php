<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddState extends Model
{
    protected $fillable = ['country' ,'state','Image',];
}
