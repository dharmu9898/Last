<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AddTrip;
use App\City;
use App\Country;
use App\State;
use DB;
use App\User;
use App\Rvsp;
use App\Package;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class GuestController extends Controller
{
    public function index()
    {
      
                        $user = DB::table('add_trips')
                        ->leftJoin('users', 'add_trips.user_id', '=', 'users.id')
                        ->leftJoin('countries','add_trips.country', '=', 'countries.country_id')
                        ->leftJoin('states','add_trips.state', '=', 'states.state_id')
                        ->leftJoin('cities','add_trips.city', '=', 'cities.city_id')
                        ->select('add_trips.*','states.state_name','countries.country_name','cities.city_name','users.name')
                        ->orderBy('add_trips.id', 'desc')
                        ->paginate(10);

                  
                    
                   /*    $gallery = DB::table('packages')
                        ->leftJoin('users', 'packages.user_id', '=', 'users.id')
                       
                
                        ->leftJoin('countries','packages.country', '=', 'countries.country_id')
                        ->leftJoin('states','packages.state', '=', 'states.state_id')
                        ->leftJoin('cities','packages.city', '=', 'cities.city_id')
                            ->select('packages.*','states.state_name','countries.country_name','cities.city_name','users.name')
                            
                           
                            ->orderBy('packages.id', 'desc')
                                     ->paginate(10);
                      
                                     $countries = Country::all()->pluck('country_name','id');*/
                 


                                /*   $gallery = DB::table('trip_categories')
                  
                       
                
                                     ->leftJoin('countries','trip_categories.country', '=', 'countries.country_id')
                                     ->leftJoin('states','trip_categories.state', '=', 'states.state_id')
                                     ->leftJoin('cities','trip_categories.city', '=', 'cities.city_id')
                                         ->select('trip_categories.*','states.state_name','countries.country_name','cities.city_name')
                                         
                                        
                                         ->orderBy('trip_categories.id', 'desc')
                                                  ->paginate(10);*/
                 
                 
                                 

       $gallery = DB::table('packages')
       ->leftJoin('trip_categories','packages.Category', '=', 'trip_categories.category')
         ->leftJoin('countries','packages.country', '=', 'countries.country_id')
       ->leftJoin('states','packages.state', '=', 'states.state_id')
    ->leftJoin('cities','packages.city', '=', 'cities.city_id')
                           
    ->select('packages.*','trip_categories.id','trip_categories.category','countries.country_name','countries.country_id','states.state_name','states.state_id','cities.city_name','cities.city_id')
                                  
                                   
                                      
                         ->orderBy('packages.id', 'desc')
                    ->paginate(10);
                     $countries = DB::table('destinations')
                                                ->leftJoin('countries','destinations.country', '=', 'countries.country_id')
                                                   
                                                ->select('destinations.*','countries.country_name','countries.country_id')
                                         
                                           

                                   
                                      
                                                ->orderBy('destinations.id', 'desc')
                                                         ->paginate(10);
               
                                          $states = DB::table('add_states')
                                       ->leftJoin('countries','add_states.country', '=', 'countries.country_id')
                                       ->leftJoin('states','add_states.state', '=', 'states.state_id')
                                                         
                                       ->select('add_states.*','countries.country_name','countries.country_id','states.state_name','states.state_id')
                                                             
         
                                            
                                               
                   ->orderBy('add_states.id', 'desc')
                                        ->paginate(10);

                                        $city = DB::table('add_cities')
                                        ->leftJoin('countries','add_cities.country', '=', 'countries.country_id')
                                        ->leftJoin('states','add_cities.state', '=', 'states.state_id')
                                        ->leftJoin('cities','add_cities.city', '=', 'cities.city_id')
                                                     
                                        ->select('add_cities.*','countries.country_name','countries.country_id','states.state_name','states.state_id','cities.city_name','cities.city_id')
                                       
                                             
                                                
                           ->orderBy('add_cities.id', 'desc')
                                         ->paginate(10);
                       return view('welcome',compact('gallery','countries','states','city'));
                           
                              //   $state = State::where('states.country_id','101')->get();         

                       
                        
               
                     //   $state= State::where('country_id','101')->pluck('state_name');
                        
                        
                 //   $state= State::where('states.country_id','101')->pluck('state_name','id');
                  //   $city = DB::table('cities')->whereIn('cities.state_id', $state)->get();
                       
               /*     $gallery = DB::table('trip_titles')
                  
                    ->leftJoin('packages','trip_titles.category', '=', 'packages.TripTitle')
                     
                    ->leftJoin('countries','packages.country', '=', 'countries.country_id')
                    ->leftJoin('states','packages.state', '=', 'states.state_id')
                    ->leftJoin('cities','packages.city', '=', 'cities.city_id')
                        ->select('trip_titles.*','states.state_name','countries.country_name','cities.city_name')
                        
                       
                        ->orderBy('trip_titles.id', 'desc')
                                 ->paginate(10);*/
                  
                             
                
                                }  
                       


               
      		
   

 
    public function getStates($id){
        $states= State::where('country_id',$id)->pluck('state_name','id');
        return json_encode($states);
    }


public function getCities($id){
        $cities= City::where('state_id',$id)->pluck('city_name','id');
        return json_encode($cities);
    }

    
    
         
    public function welcome_fetchs_data(Request $request){
        if($request->ajax()){
            $manual_filter = $request->get('manual_filter_table');
            $mfilter = str_replace("","%",$manual_filter);
            $gallery = DB::table('trip_categories')
            
            ->where('trip_categories.category', 'like', '%'.$mfilter.'%')
            
            //  ->orwhere(function ($query) use ($mfilter) {
            // })
            ->orderBy('trip_categories.id', 'DESC')
            ->paginate(30);
            return view('pagess', compact('gallery'))->render();
        }
    }
    public function welcome_fetch_country(Request $request){
        if($request->ajax()){
            $manual_filter = $request->get('manual_filter_country');
            $mfilter = str_replace("","%",$manual_filter);
            $countries = DB::table('destinations')
            ->join('countries','destinations.country', '=', 'countries.country_id')
           
            
              ->where(function ($query) use ($mfilter) {

               $query->Where('countries.country_name', 'like', '%'.$mfilter.'%');
             })
            ->orderBy('destinations.id', 'DESC')
            ->paginate(30);
            return view('page', compact('countries'))->render();
        }
    }


    public function welcome_fetching_data(Request $request){
      
           

        if($request->ajax()){
            $manual_filter = $request->get('manual_filter_tables');
              $manual_filter_tablesm = $request->get('manual_filter_tablesm1');
            $mfiltersm = str_replace("","%",$manual_filter_tablesm);
            if($manual_filter != null){
            $states = DB::table('add_states')
                   
                    ->join('countries','add_states.country', '=', 'countries.country_id')
                    ->join('states','add_states.state', '=', 'states.state_id')
                   
                    ->where(function ($query) use ($manual_filter) {
              
                        $query->Where('add_states.country', $manual_filter)
                        ->orWhere('add_states.state', $manual_filter);
               
                    })
                
                ->orderBy('add_states.id', 'DESC')
                ->paginate(10);
                } else{
            $states = DB::table('add_states')
                   
       ->leftJoin('countries','add_states.country', '=', 'countries.country_id')
       ->leftJoin('states','add_states.state', '=', 'states.state_id')
       
        ->where(function ($query) use ($mfiltersm) {
              
                 $query->Where('countries.country_name', 'like', '%'.$mfiltersm.'%')
            ->orWhere('states.state_name', 'like', '%'.$mfiltersm.'%');
             
                })
                ->orderBy('add_states.id', 'DESC')
                ->paginate(30);
                      }
            return view('state', compact('states'))->render();


          
        
        }
    }
    public function welcome_fetching_city(Request $request){
      
           

        if($request->ajax()){
            $manual_filter = $request->get('manual_filter_cont');
              $manual_filter_tablesm = $request->get('manual_filter_tablesms');
            $mfiltersm = str_replace("","%",$manual_filter_tablesm);
            if($manual_filter != null){
                $gallery = DB::table('packages')
                   
                ->join('countries','packages.country', '=', 'countries.country_id')
                ->join('states','packages.state', '=', 'states.state_id')
                ->join('cities','packages.city', '=', 'cities.city_id')
                ->where(function ($query) use ($manual_filter) {
          
                    $query->Where('packages.country', $manual_filter)
                    ->orWhere('packages.state', $manual_filter)
             ->orWhere('packages.city', $manual_filter);  
                })
            
            ->orderBy('packages.id', 'DESC')
            ->paginate(10);
            } else{
        $gallery = DB::table('packages')
               
   ->leftJoin('countries','packages.country', '=', 'countries.country_id')
   ->leftJoin('states','packages.state', '=', 'states.state_id')
   ->leftJoin('cities','packages.city', '=', 'cities.city_id')
    ->where(function ($query) use ($mfiltersm) {
          
             $query->Where('countries.country_name', 'like', '%'.$mfiltersm.'%')
        ->orWhere('states.state_name', 'like', '%'.$mfiltersm.'%')
        ->orWhere('cities.city_name', 'like', '%'.$mfiltersm.'%');   
            })
            ->orderBy('packages.id', 'DESC')
            ->paginate(30);
                  }
        return view('pagess', compact('gallery'))->render();



          
        
        }
    }

    public function welcome_fetch_data(Request $request){
      
           

        if($request->ajax()){
            $manual_filter = $request->get('manual_filter_table');
              $manual_filter_tablesm = $request->get('manual_filter_tablesm');
            $mfiltersm = str_replace("","%",$manual_filter_tablesm);
            if($manual_filter != null){
            $gallery = DB::table('packages')
                   
                    ->join('countries','packages.country', '=', 'countries.country_id')
                    ->join('states','packages.state', '=', 'states.state_id')
                    ->join('cities','packages.city', '=', 'cities.city_id')
                    ->where(function ($query) use ($manual_filter) {
              
                        $query->Where('packages.country', $manual_filter)
                        ->orWhere('packages.state', $manual_filter)
                 ->orWhere('packages.city', $manual_filter);  
                    })
                
                ->orderBy('packages.id', 'DESC')
                ->paginate(10);
                } else{
            $gallery = DB::table('packages')
                   
       ->leftJoin('countries','packages.country', '=', 'countries.country_id')
       ->leftJoin('states','packages.state', '=', 'states.state_id')
       ->leftJoin('cities','packages.city', '=', 'cities.city_id')
        ->where(function ($query) use ($mfiltersm) {
              
                 $query->where('packages.TripTitle', 'like', '%'.$mfiltersm.'%')
                    ->orWhere('packages.datetime', 'like', '%'.$mfiltersm.'%')
                    ->orWhere('packages.Category', 'like', '%'.$mfiltersm.'%')
            ->orWhere('countries.country_name', 'like', '%'.$mfiltersm.'%')
            ->orWhere('states.state_name', 'like', '%'.$mfiltersm.'%')
            ->orWhere('cities.city_name', 'like', '%'.$mfiltersm.'%');   
                })
                ->orderBy('packages.id', 'DESC')
                ->paginate(30);
                      }
            return view('category', compact('gallery'))->render();


          
        
        }
    }
         
    

    public function welcome_fetch_dashboard(Request $request){
      
           

        if($request->ajax()){
            $manual_filter = $request->get('manual_filter_table');
              $manual_filter_tablesm = $request->get('manual_filter_tablesm');
            $mfiltersm = str_replace("","%",$manual_filter_tablesm);
            if($manual_filter != null){
            $gallery = DB::table('packages')
                   
                    ->join('countries','packages.country', '=', 'countries.country_id')
                    ->join('states','packages.state', '=', 'states.state_id')
                    ->join('cities','packages.city', '=', 'cities.city_id')
                  
                    ->where(function ($query) use ($manual_filter) {
              
                        $query->Where('packages.country', $manual_filter)
                        ->orWhere('packages.state', $manual_filter)
                 ->orWhere('packages.city', $manual_filter); 
               
                    })
                
                ->orderBy('packages.id', 'DESC')
                ->paginate(10);
                } else{
            $gallery = DB::table('packages')
                   
       ->leftJoin('countries','packages.country', '=', 'countries.country_id')
       ->leftJoin('states','packages.state', '=', 'states.state_id')
       ->leftJoin('cities','packages.city', '=', 'cities.city_id')
        ->where(function ($query) use ($mfiltersm) {
              
                 $query->where('packages.TripTitle', 'like', '%'.$mfiltersm.'%')
                    ->orWhere('packages.datetime', 'like', '%'.$mfiltersm.'%')
                    ->orWhere('packages.Category', 'like', '%'.$mfiltersm.'%')
            ->orWhere('countries.country_name', 'like', '%'.$mfiltersm.'%')
            ->orWhere('states.state_name', 'like', '%'.$mfiltersm.'%')
            ->orWhere('cities.city_name', 'like', '%'.$mfiltersm.'%');   
                })
                ->orderBy('packages.id', 'DESC')
                ->paginate(30);
                      }
            return view('pagess', compact('gallery'))->render();


          
        
        }
    }
      
                           


    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
  
    //
    public function getRole(Request $request){

        
        if($request->ajax()){
            $filter_city = $request->get('filter_city');
            $profiles =DB::table('add_trips')
           
            ->join('cities','add_trips.city', '=','cities.city_id')
          
            ->where(function ($query) use ($filter_city) {
            if($filter_city != "all"){
                $query->where('profiles.city',$filter_city);
                }
            })
            ->orderBy('add_trips.id','desc')->paginate(30);
            return view('paginated_data', compact('profiles'))->render();
        }
    }


    public function welcome_country(Request $request){

        if($request->ajax()){
            $filter_city = $request->get('filter_city');
            $gallery =DB::table('Packages')
           
          
            ->join('cities','Packages.city', '=','cities.city_id')
            ->where(function ($query) use ($filter_city) {
            if($filter_city != "all"){
                $query->where('Packages.city',$filter_city);
                }
            })
            ->orderBy('Packages.id','desc')->paginate(30);
            return view('page', compact('gallery'))->render();
     


  
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


     
        $addrequest = new Rvsp();
           
        $sub=$request->TripTitle;
        DB::table('packages')
        ->where('TripTitle', $sub)
        ->increment('Subscriber', 1);

       
               // return  $rest;
        
         $addrequest->emailid= $request->emailid;
         $addrequest->Phoneno =  $request->Phoneno;
         $addrequest->Name =  $request->Name;
         $addrequest->Address =  $request->Address;
         $addrequest->TripTitle =  $request->TripTitle;
                $addrequest->save();

               
            // send mail for tour operator

           return redirect()->back()->with('success', ' your message send Successfully ');

         
  

      
    }

    
    public function show($name)
    {

        $title = str_replace('-',' ',$name); 
        
   $gallery = DB::table('packages')
        ->leftJoin('users', 'packages.id', '=', 'users.id')
        ->leftJoin('countries','packages.country', '=', 'countries.country_id')
       ->leftJoin('states','packages.state', '=', 'states.state_id')
      ->leftJoin('cities','packages.city', '=', 'cities.city_id')
      ->select('packages.*','countries.country_name','states.state_name','cities.city_name','users.name')
      ->where('packages.TripTitle', $title)
      ->first();


return view('show', compact('gallery')); 
    }

    public function showcategory($category)
    {
        
        $gallery = DB::table('packages')
        ->leftJoin('users', 'packages.id', '=', 'users.id')
        ->leftJoin('countries','packages.country', '=', 'countries.country_id')
        ->leftJoin('trip_categories','packages.Category', '=', 'trip_categories.category')              
       ->leftJoin('states','packages.state', '=', 'states.state_id')
      ->leftJoin('cities','packages.city', '=', 'cities.city_id')
      ->select('packages.*','trip_categories.Describe','countries.country_name','states.state_name','cities.city_name','users.name')
      ->where('packages.Category', $category)
      ->orderBy('packages.id', 'desc')
      ->paginate(10);

return view('showcategory', compact('gallery')); 
    }
    public function showcountry($slug2)
    {
        
        $gallery = DB::table('packages')
        ->leftJoin('users', 'packages.id', '=', 'users.id')
        ->leftJoin('countries','packages.country', '=', 'countries.country_id')
        
       ->leftJoin('states','packages.state', '=', 'states.state_id')
      ->leftJoin('cities','packages.city', '=', 'cities.city_id')
      ->select('packages.*','countries.country_name','states.state_name','cities.city_name','users.name')
      ->where('packages.slug2', $slug2)
       
      ->orderBy('packages.id', 'desc')
      ->paginate(10);

      $countries = Country::all()->pluck('country_name','id');
                 

return view('showcategory', compact('gallery','countries')); 
    }
    public function showstate($slug1)
    {
        
        $gallery = DB::table('packages')
        ->leftJoin('users', 'packages.id', '=', 'users.id')
       ->leftJoin('states','packages.state', '=', 'states.state_id')
      ->leftJoin('cities','packages.city', '=', 'cities.city_id')
      ->select('packages.*','cities.city_name','users.name')
      ->where('packages.slug1', $slug1)
      ->first();


return view('showcategory', compact('gallery')); 
    }
    public function showcity($slug)
    {
        
        $gallery = DB::table('packages')
        ->leftJoin('users', 'packages.id', '=', 'users.id')
       ->leftJoin('states','packages.state', '=', 'states.state_id')
      ->leftJoin('cities','packages.city', '=', 'cities.city_id')
      ->select('packages.*','cities.city_name','users.name')
      ->where('packages.slug', $slug)
      ->first();


return view('showcategory', compact('gallery')); 
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
