<?php

namespace App\Http\Controllers\Admin;



use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\User;
use DB;
use App\City;
use App\Country;
use App\State;
use Auth;
use App\Package;
use Illuminate\Support\Facades\Log;



class AdminTPController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        
      
        $users = User::where('role_id', '2')
        ->leftJoin('countries','users.Country', '=', 'countries.country_id')
        ->leftJoin('states','users.state', '=', 'states.state_id')
        ->leftJoin('cities','users.city', '=', 'cities.city_id')
        ->select('users.*','cities.city_name','countries.country_name','states.state_name','users.name')

        
        
        ->orderBy('id', 'desc')->paginate(6);
       
        return view('admin.operator.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    
    {

        
        $countries = DB::table('countries')->get();
       
        
      // $states = State::where('states.country_id', $countries)->get();
     // $city = DB::table('cities')->whereIn('cities.state_id', $states)->get();

        return view('admin.operator.create', compact('countries'));
    }
    public function getStates($id){
        $states= State::where('country_id',$id)->pluck('state_name','id');
        return json_encode($states);
    }


public function getCities($id){
        $cities= City::where('state_id',$id)->pluck('city_name','id');
        return json_encode($cities);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       

        $data = $request->email;
        
        $email = User::where('email',$data)->first();
        if($email){
           return redirect()->back()->with('success', 'Email is already exists.');
        }
        $this->validate($request,[
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'Phoneno' => 'required',
            'experience' => 'required',
            'password' => 'required'
           
          
            

        ]);
        $user = new User();
        $user->name =  $request->name;
        $user->email = $request->email;
        $user->Phoneno =  $request->Phoneno;
       
        $user->password =  $request->password;
        $user->Experience = $request->experience;
        $user->Country =  $request->country;
        $user->State =  $request->state;
        $user->City =  $request->city;
        $user->role_id = "2";
     
        $user->save();
            // send mail for tour operator

        return redirect()->route('admin.operator.index')->with('success', ' Manager Added Successfully ');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $operators = DB::table('users')
        ->leftJoin('countries','users.Country', '=', 'countries.country_id')
        ->leftJoin('states','users.state', '=', 'states.state_id')
        ->leftJoin('cities','users.city', '=', 'cities.city_id')
        ->select('users.*','cities.city_name','countries.country_name','states.state_name','users.name')
        ->where('users.id', $id)
        ->first();       
                  
        return view('admin.operator.show', compact('operators'));
     


        
    }
    public function changepassword($id){
        $users = User::find($id);
      return view('admin.adminchangepassword',compact('users'));
    }

    public function changePasswordUpdate(Request $request ,$id)
    {

     $request->validate([

        'password'=> 'required'

     ]);
     $user = Auth::user();
     $user->password = bcrypt($request->get('password'));
     $user->save();
     return back()->with('success','Password changed Successfully');
    }


    public function welcome_fetch_data(Request $request){
        if($request->ajax()){
            $manual_filter = $request->get('manual_filter_table');
              $manual_filter_tablesm = $request->get('manual_filter_tablesm');
            $mfiltersm = str_replace("","%",$manual_filter_tablesm);
            if($manual_filter != null){
            $users = DB::table('users')
                    ->where('role_id',2)
                    ->join('countries','users.country', '=', 'countries.country_id')
                    ->join('states','users.state', '=', 'states.state_id')
                    ->join('cities','users.city', '=', 'cities.city_id')
                    ->where(function ($query) use ($manual_filter) {
              
                        $query->Where('users.country', $manual_filter)
                        ->orWhere('users.state', $manual_filter)
                 ->orWhere('users.city', $manual_filter);  
                    })
                
                ->orderBy('users.id', 'DESC')
                ->paginate(10);
                } else{
            $users = DB::table('users')
                    ->where('role_id',2)
                    ->leftJoin('countries','users.country', '=', 'countries.country_id')
                    ->leftJoin('states','users.state', '=', 'states.state_id')
                    ->leftJoin('cities','users.city', '=', 'cities.city_id')
                   ->where(function ($query) use ($mfiltersm) {
              
                    $query->where('users.name', 'like', '%'.$mfiltersm.'%')
                    ->orWhere('users.email', 'like', '%'.$mfiltersm.'%')
            ->orWhere('countries.country_name', 'like', '%'.$mfiltersm.'%')
            ->orWhere('states.state_name', 'like', '%'.$mfiltersm.'%')
            ->orWhere('cities.city_name', 'like', '%'.$mfiltersm.'%');   
                })
                ->orderBy('users.id', 'DESC')
                ->paginate(30);
                      }
                      return view('admin.operator.paginated_data', compact('users'))->render();  }
    }


/*    public function welcome_fetch_data(Request $request){
        if($request->ajax()){

          
            $manual_filter = $request->get('manual_filter_tablesm');
            $mfilter = str_replace("","%",$manual_filter);
           
            $users =  User::where('role_id', '2')
            ->leftJoin('countries','users.Country', '=','countries.country_id')
            ->leftJoin('cities','users.City', '=','cities.city_id')
            ->leftJoin('states','users.State', '=','states.state_id')

            ->where(function ($query) use ($mfilter) {
              
                    $query->where('users.name', 'like', '%'.$mfilter.'%')
                    ->orWhere('users.email', 'like', '%'.$mfilter.'%')
            ->orWhere('countries.country_name', 'like', '%'.$mfilter.'%')
            ->orWhere('states.state_name', 'like', '%'.$mfilter.'%')
            ->orWhere('cities.city_name', 'like', '%'.$mfilter.'%');   
                })
            
            
            //  ->orwhere(function ($query) use ($mfilter) {
            // })
            ->orderBy('users.id', 'DESC')
            ->paginate(30);
          
            return view('admin.operator.paginated_data', compact('users'))->render();
        }
    }*/

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      //  $users = User::where('id',  '=', $id)->orderBy('id', 'desc')->first()
       //->paginate(5);


     


       $find = User::find($id);
        
      
        
       $country_id = $find->Country;    
       $country = Country::where("country_id" , $country_id)->first();
       if($find->Country == 'Country')
       {

        $country_name = 'Country'; 
        

       }
       else{
       $country_name = $country->country_name;    
        } 
       
       $state_id = $find->State;
       $state = State::where('state_id',$state_id)->first();
   
       if($find->State == 'State')
       {

        $state_name = 'State'; 
        

       }
       else{
        $state_name = $state->state_name;   
              } 
       $city_id = $find->City;
       $city = City::where('city_id',$city_id)->first();

       if($find->City == 'City')
       {

        $city_name = 'City'; 
        

       }
       else{
        $city_name = $city->city_name;  
              } 


     
               
     return view('admin.operator.edit',compact('id' ,'country_name','country_id','state_name', 'state_id','city_name','city_id'))->with('data',$find);
        
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'name' => 'required',
            'email' => 'required',
            'Phoneno' => 'required',
            'experience' => 'required'
           
           
          
            

        ]);
        $user = User::find($id);

        $user->name =  $request->name;
        $user->email = $request->email;
        $user->Phoneno =  $request->Phoneno;
       
       
        $user->Experience = $request->experience;
        $user->Country =  $request->country;
        $user->State =  $request->state;
        $user->City =  $request->city;
        $user->role_id = "2";
     
        $user->save();
            // send mail for tour operator

        return redirect()->route('admin.operator.index')->with('success', ' operator Added Successfully ');
  
        




        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
        $user = User::find($id);
        $user->delete();
        return redirect()->route('admin.operator.index')->with('danger', 'operator access has been Deleted!');
 

    }
}
