<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rvsp extends Model
{ 
    protected $fillable = ['emailid','Phoneno','Name','TripTitle','Address'];

   
}
