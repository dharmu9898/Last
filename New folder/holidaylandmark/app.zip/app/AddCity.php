<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddCity extends Model
{
    protected $fillable = ['country' ,'state','city','Image',];
}
